;(function(){try{globalThis.__AF_BUILD__={"id":"af_10.7.65_google_20260417_024015_119e751","version":"10.7.65","recipient":"google","channel":"release","commit":"119e751"}}catch(_e){}})();
chrome.action.onClicked.addListener(e=>{e.id&&chrome.sidePanel.open({windowId:e.windowId})}),chrome.runtime.onInstalled.addListener(e=>{e.reason==="install"?chrome.tabs.create({url:"https://ergophobia.info/autoflow"}):e.reason==="update"&&chrome.tabs.create({url:"https://ergophobia.info/autoflow?changelog"})});function bgLog(e,t,r){console.log(`[AutoFlow BG] ${t}`),chrome.tabs.query({url:"https://labs.google/fx/*"},a=>{for(const i of a||[])chrome.tabs.sendMessage(i.id,{type:"OPENCLAW_BG_LOG",level:e,source:"background",message:t,data:r}).catch(()=>{})})}const FLOW_SESSION_COOKIE_PRESERVE_PREFIXES=["__Secure-next-auth.","__Host-next-auth."],FLOW_SESSION_COOKIE_PRESERVE_NAMES=new Set(["EMAIL","email"]),FLOW_SESSION_COOKIE_DOMAIN_REGEX=/(^|\.)labs\.google(\.com)?$/i;function isFlowSessionCookieDomain(e=""){return FLOW_SESSION_COOKIE_DOMAIN_REGEX.test(String(e||"").trim())}function shouldPreserveFlowSessionCookie(e={}){const t=String(e?.name||"").trim();return t?FLOW_SESSION_COOKIE_PRESERVE_NAMES.has(t)?true:FLOW_SESSION_COOKIE_PRESERVE_PREFIXES.some(r=>t.startsWith(r)):false}function afBuildCookieUrl(e={}){const t=String(e?.domain||"").trim().replace(/^\./,"");if(!t)return"";const r=String(e?.path||"/").trim()||"/";return`${e?.secure?"https":"http"}://${t}${r.startsWith("/")?r:`/${r}`}`}function afGetAllCookies(){return new Promise(e=>{try{chrome.cookies.getAll({},t=>{if(chrome.runtime.lastError){e({ok:false,error:chrome.runtime.lastError.message||"cookies_get_all_failed",cookies:[]});return}e({ok:true,cookies:Array.isArray(t)?t:[]})})}catch(t){e({ok:false,error:t?.message||"cookies_get_all_failed",cookies:[]})}})}function afRemoveCookie(e={}){return new Promise(t=>{try{chrome.cookies.remove(e,r=>{if(chrome.runtime.lastError){t({ok:false,error:chrome.runtime.lastError.message||"cookie_remove_failed"});return}t({ok:!!r,removed:r||null})})}catch(r){t({ok:false,error:r?.message||"cookie_remove_failed"})}})}async function afResetLabsFlowSessionCookies(){const e=await afGetAllCookies();if(!e.ok)return{ok:false,error:e.error||"cookies_get_all_failed",removedCount:0,preservedCount:0,preservePrefixes:[...FLOW_SESSION_COOKIE_PRESERVE_PREFIXES],preserveNames:[...FLOW_SESSION_COOKIE_PRESERVE_NAMES]};const t=e.cookies.filter(o=>isFlowSessionCookieDomain(o?.domain||"")),r=[],a=[];for(const o of t)shouldPreserveFlowSessionCookie(o)?r.push(o):a.push(o);let i=0;const m=[];for(const o of a){const f=afBuildCookieUrl(o);if(!f){m.push(`missing_url:${String(o?.name||"unknown")}`);continue}const g=await afRemoveCookie({url:f,name:String(o?.name||""),storeId:o?.storeId});g.ok?i+=1:m.push(`${String(o?.name||"unknown")}:${String(g.error||"remove_failed")}`)}return{ok:m.length===0,error:m.length>0?m.slice(0,10).join(","):"",totalLabsCookies:t.length,removedCount:i,preservedCount:r.length,preservePrefixes:[...FLOW_SESSION_COOKIE_PRESERVE_PREFIXES],preserveNames:[...FLOW_SESSION_COOKIE_PRESERVE_NAMES],removedNames:a.map(o=>String(o?.name||"")).filter(Boolean).slice(0,20),preservedNames:r.map(o=>String(o?.name||"")).filter(Boolean).slice(0,20)}}async function afGetLabsFlowAuthCookieState(){const e=await afGetAllCookies();if(!e.ok)return{ok:false,error:e.error||"cookies_get_all_failed",present:false,preservedCount:0,preservePrefixes:[...FLOW_SESSION_COOKIE_PRESERVE_PREFIXES],preserveNames:[...FLOW_SESSION_COOKIE_PRESERVE_NAMES],presentNames:[]};const t=e.cookies.filter(a=>isFlowSessionCookieDomain(a?.domain||"")),r=t.filter(a=>shouldPreserveFlowSessionCookie(a));return{ok:true,present:r.length>0,totalLabsCookies:t.length,preservedCount:r.length,preservePrefixes:[...FLOW_SESSION_COOKIE_PRESERVE_PREFIXES],preserveNames:[...FLOW_SESSION_COOKIE_PRESERVE_NAMES],presentNames:r.map(a=>String(a?.name||"")).filter(Boolean).slice(0,20)}}chrome.storage.local.get("af_reload_tab_id",e=>{if(e&&e.af_reload_tab_id){const t=e.af_reload_tab_id;chrome.storage.local.remove("af_reload_tab_id"),setTimeout(()=>{chrome.tabs.get(t,r=>{chrome.runtime.lastError||!r||chrome.sidePanel.open({windowId:r.windowId}).then(()=>{chrome.tabs.reload(t).catch(()=>{})}).catch(()=>{chrome.tabs.reload(t).catch(()=>{})})})},500)}});let interceptFlowDownloads=false,interceptTimeout=null,cancelFlowDownloads=true;const ourDownloadIds=new Set,ourPendingUrls=new Set,pendingFlowDownloadNames=[],pendingDirectDownloadNames=[],badMediaResolveUrlCache=new Set,DIRECT_DOWNLOAD_NAMES_STORAGE_KEY="af_pending_direct_download_names_v1",FLOW_DOWNLOAD_NAME_TTL_MS=6e5,FLOW_INTERCEPT_DEFAULT_TIMEOUT_MS=3e5,FLOW_INTERCEPT_MAX_TIMEOUT_MS=9e5,DIRECT_DOWNLOAD_NAME_TTL_MS=18e4;function isFlowDownloadUrl(e=""){try{const t=new URL(e);if(t.protocol!=="https:")return false;const r=t.hostname.toLowerCase();return r==="storage.googleapis.com"||r.endsWith(".storage.googleapis.com")||r.includes("googleusercontent.com")||r.includes("googlevideo.com")||r.includes("gvt1.com")||r==="video.google.com"||r.endsWith(".video.google.com")}catch{return false}}function cleanupPendingFlowNames(){const e=Date.now()-FLOW_DOWNLOAD_NAME_TTL_MS;for(let t=pendingFlowDownloadNames.length-1;t>=0;t--)(pendingFlowDownloadNames[t]?.createdAt||0)<e&&pendingFlowDownloadNames.splice(t,1)}function cleanupPendingDirectNames(){const e=Date.now()-DIRECT_DOWNLOAD_NAME_TTL_MS;for(let t=pendingDirectDownloadNames.length-1;t>=0;t--)(pendingDirectDownloadNames[t]?.createdAt||0)<e&&pendingDirectDownloadNames.splice(t,1)}function getPendingDirectNameStore(){return chrome.storage?.session||chrome.storage?.local||null}function persistPendingDirectNames(){const e=getPendingDirectNameStore();if(e?.set)try{const t=pendingDirectDownloadNames.map(r=>({...r}));e.set({[DIRECT_DOWNLOAD_NAMES_STORAGE_KEY]:t},()=>{chrome.runtime?.lastError})}catch{}}async function ensurePendingDirectNamesLoaded(){if(pendingDirectDownloadNames.length>0){cleanupPendingDirectNames(),persistPendingDirectNames();return}const e=getPendingDirectNameStore();if(!e?.get){cleanupPendingDirectNames();return}await new Promise(t=>{try{e.get([DIRECT_DOWNLOAD_NAMES_STORAGE_KEY],r=>{const a=Array.isArray(r?.[DIRECT_DOWNLOAD_NAMES_STORAGE_KEY])?r[DIRECT_DOWNLOAD_NAMES_STORAGE_KEY]:[];pendingDirectDownloadNames.length=0,a.forEach(i=>pendingDirectDownloadNames.push(i)),cleanupPendingDirectNames(),persistPendingDirectNames(),t()})}catch{t()}})}function registerPendingFlowName(e,t){!e||typeof e!="string"||(cleanupPendingFlowNames(),pendingFlowDownloadNames.push({filename:e,urlBase:typeof t=="string"?t.split("?")[0]:null,createdAt:Date.now()}))}function registerPendingDirectName(e,t){!e||typeof e!="string"||(cleanupPendingDirectNames(),pendingDirectDownloadNames.push({filename:e,urlBase:typeof t=="string"?t.split("?")[0]:null,createdAt:Date.now()}),persistPendingDirectNames())}function consumePendingFlowNameForUrl(e=""){cleanupPendingFlowNames();const t=e.split("?")[0];let r=pendingFlowDownloadNames.findIndex(o=>o.urlBase&&o.urlBase===t);const a=r!==-1?"exact":void 0;if(r===-1&&(r=pendingFlowDownloadNames.findIndex(o=>!o.urlBase)),r===-1&&(r=pendingFlowDownloadNames.length>0?0:-1),r===-1)return bgLog("warn",`[AutoFlow 1080p] pending_name_miss url=${t.slice(-80)} pending_count=${pendingFlowDownloadNames.length} pending_urls=${pendingFlowDownloadNames.map(o=>(o.urlBase||"null").slice(-40)).join(",")}`),null;const i=a||(pendingFlowDownloadNames[r]&&!pendingFlowDownloadNames[r].urlBase?"null_urlbase":"greedy_first"),[m]=pendingFlowDownloadNames.splice(r,1);return bgLog("info",`[AutoFlow 1080p] pending_name_consumed matched=true method=${i} filename=${m?.filename?.slice(-60)||"none"} url=${t.slice(-80)} remaining=${pendingFlowDownloadNames.length}`),m||null}async function consumePendingDirectNameForUrl(e=""){await ensurePendingDirectNamesLoaded(),cleanupPendingDirectNames();const t=e.split("?")[0];let r=pendingDirectDownloadNames.findIndex(i=>i.urlBase&&i.urlBase===t);if(r===-1&&(r=pendingDirectDownloadNames.findIndex(i=>!i.urlBase)),r===-1&&(r=pendingDirectDownloadNames.length>0?0:-1),r===-1)return persistPendingDirectNames(),null;const[a]=pendingDirectDownloadNames.splice(r,1);return persistPendingDirectNames(),a||null}chrome.downloads.onDeterminingFilename.addListener((e,t)=>((async()=>{cleanupPendingFlowNames();const r=e.url||"",a=await consumePendingDirectNameForUrl(r);if(a?.filename){t({filename:a.filename,conflictAction:"uniquify"});return}if(!interceptFlowDownloads&&pendingFlowDownloadNames.length===0||ourDownloadIds.has(e.id)){t();return}const i=isFlowDownloadUrl(r),m=pendingFlowDownloadNames.length>0;if(!i&&!m){t();return}const o=consumePendingFlowNameForUrl(r);if(!o?.filename){bgLog("warn",`[AutoFlow 1080p] onDeterminingFilename_passthrough url=${r.slice(-80)} isFlowUrl=${i} pendingCount=${m?pendingFlowDownloadNames.length:0}`),t();return}bgLog("info",`[AutoFlow 1080p] onDeterminingFilename_renamed url=${r.slice(-80)} filename=${o.filename.slice(-60)}`),t({filename:o.filename,conflictAction:"uniquify"})})().catch(()=>t()),true)),chrome.downloads.onCreated.addListener(e=>{if(!interceptFlowDownloads||!cancelFlowDownloads||ourDownloadIds.has(e.id))return;const t=e.url||"",r=t.split("?")[0];ourPendingUrls.has(r)||isFlowDownloadUrl(t)&&e.id&&chrome.downloads.cancel(e.id,()=>{bgLog("info",`Cancelled Flow download #${e.id} (extension handles naming)`)})}),chrome.runtime.onMessage.addListener((e,t,r)=>{const a=e?.__afBridgeForwarded===true,i=e.type==="AF_BOT_BRIDGE_COMMAND",m=e.type==="AF_BOT_COMMAND"&&!a&&!!t?.tab?.id;if(i||m){const o=t?.tab||null,f={...e,type:"AF_BOT_COMMAND",__afBridgeForwarded:true},g=(s,n="")=>{r?.({status:s,log:n||s,bridgeError:true})},u=async()=>{if(!m)return true;if(typeof chrome.runtime.getContexts!="function")return false;const s=o?.windowId;if(!Number.isInteger(s))return true;try{const n=await chrome.runtime.getContexts({contextTypes:["SIDE_PANEL"],windowIds:[s]});return!Array.isArray(n)||n.length===0}catch{return false}},h=s=>{try{chrome.runtime.sendMessage(f,n=>{if(chrome.runtime.lastError){s(chrome.runtime.lastError.message||"No sidepanel response",null);return}s(null,n||null)})}catch(n){s(n?.message||"Bridge forward failed",null)}};return(async()=>{await u()&&h((s,n)=>{if(!s&&n){r?.(n);return}const l=o?.windowId;if(!Number.isInteger(l)){g("Bridge unavailable — open Auto Flow sidepanel and refresh Flow tab",s||"Missing sender window");return}chrome.sidePanel.open({windowId:l},()=>{setTimeout(()=>{h((d,c)=>{if(!d&&c){r?.(c);return}g("Bridge unavailable — refresh Flow tab to reconnect OpenClaw panel",d||s||"No response after sidepanel reopen")})},260)})})})().catch(s=>{if(i){g("Bridge unavailable — refresh Flow tab to reconnect OpenClaw panel",s?.message||"Bridge internal error");return}}),true}if(e?.action==="AF_RESOLVE_MEDIA_URL"){const o=String(e.url||"").trim(),f=Number.parseInt(String(e.tabId||""),10);return o?badMediaResolveUrlCache.has(o)?(r?.({ok:false,error:"invalid_redirect_input_cached"}),true):Number.isInteger(f)?(chrome.scripting.executeScript({target:{tabId:f},world:"MAIN",func:async g=>{if(!g||!String(g).toLowerCase().includes("getmediaurlredirect"))return{ok:false,error:"not_redirect_url"};let u="";try{const n=new URL(String(g)),l=n.searchParams.get("name");if(l)u=decodeURIComponent(l);else{const d=n.searchParams.get("input");if(d)try{const c=JSON.parse(decodeURIComponent(d));u=c?.json?.name||c?.name||c?.[0]?.json?.name||""}catch{}}}catch{}if(!u)return{ok:false,error:"no_media_name"};const h=(/\/media\/([^/?#]+)/i.exec(u)||[,u])[1]||u;if(!h)return{ok:false,error:"invalid_media_name"};const s=`https://labs.google/fx/api/trpc/media.getMediaUrlRedirect?name=${encodeURIComponent(h)}&mediaUrlType=MEDIA_URL_TYPE_UNSPECIFIED`;try{const n=await fetch(s,{credentials:"same-origin",redirect:"follow",headers:{accept:"application/json, text/plain, */*"}});if(n.redirected||n.url&&n.url!==s&&!n.url.toLowerCase().includes("getmediaurlredirect"))return{ok:true,url:n.url};try{const l=await n.clone().json(),d=l?.result?.data?.json?.url||l?.result?.data?.json?.redirectUrl||l?.result?.data?.url||l?.result?.url||l?.url||"";if(d&&typeof d=="string"&&/^https?:\/\//i.test(d))return{ok:true,url:d}}catch{}return n.ok?{ok:false,error:"no_url_in_response"}:{ok:false,error:`status_${n.status}`}}catch(n){return{ok:false,error:n?.message||"fetch_failed"}}},args:[o]}).then(g=>{const u=g?.[0]?.result||{};if(u?.ok&&u.url){r?.({ok:true,url:u.url});return}const h=String(u?.error||"");if((h.includes("invalid_redirect_input")||h.includes("invalid_media_name")||h.includes("status_400"))&&(badMediaResolveUrlCache.add(o),badMediaResolveUrlCache.size>500)){const s=badMediaResolveUrlCache.values().next().value;s&&badMediaResolveUrlCache.delete(s)}r?.({ok:false,error:u?.error||"resolve_failed"})}).catch(g=>{const u=g?.message||"execute_failed";if((u.includes("Cannot access contents of url")||u.includes("sorry"))&&(badMediaResolveUrlCache.add(o),badMediaResolveUrlCache.size>500)){const h=badMediaResolveUrlCache.values().next().value;h&&badMediaResolveUrlCache.delete(h)}r?.({ok:false,error:u})}),true):(r?.({ok:false,error:"bad_tab_id"}),true):(r?.({ok:false,error:"no_url"}),true)}if(e.type==="interceptFlowDownload"){if(interceptFlowDownloads=!!e.active,cancelFlowDownloads=e.cancelNative===void 0?true:!!e.cancelNative,clearTimeout(interceptTimeout),e.active){const o=Number(e.timeoutMs),f=Number.isFinite(o)?Math.min(Math.max(Math.floor(o),1e4),FLOW_INTERCEPT_MAX_TIMEOUT_MS):FLOW_INTERCEPT_DEFAULT_TIMEOUT_MS;interceptTimeout=setTimeout(()=>{interceptFlowDownloads=false},f),e.clearPending===true&&(pendingFlowDownloadNames.length=0)}else e.clearPending===true&&(pendingFlowDownloadNames.length=0);r?.({success:true,active:interceptFlowDownloads,pendingCount:pendingFlowDownloadNames.length});return}if(e.type==="registerFlowDownloadName"){registerPendingFlowName(e.filename,e.url),r?.({success:true});return}if(e.type==="AUTOFLOW_API_INTERCEPT"){try{const o=chrome?.runtime?.sendMessage?.(e);o?.catch&&o.catch(()=>{})}catch{}return}if(e.type==="AUTOFLOW_API_SNIFF"){try{const o=chrome?.runtime?.sendMessage?.(e);o?.catch&&o.catch(()=>{})}catch{}return}if(e.type==="AUTOFLOW_PROOF_LOG"){try{const o=chrome?.runtime?.sendMessage?.(e);o?.catch&&o.catch(()=>{})}catch{}return}if(e.type==="registerPendingDirectName"){registerPendingDirectName(String(e.filename||""),String(e.url||"")),r?.({success:true});return}if(e.type==="openDownloadsSettings"&&chrome.tabs.create({url:"chrome://settings/downloads"}),e.type==="AF_RESET_LABS_FLOW_SESSION_COOKIES")return(async()=>{const o=await afResetLabsFlowSessionCookies();r?.(o)})(),true;if(e.type==="AF_GET_LABS_FLOW_AUTH_COOKIE_STATE")return(async()=>{const o=await afGetLabsFlowAuthCookieState();r?.(o)})(),true;if(e.type==="downloadFile"){if(e.url&&e.filename){let o;try{o=new URL(e.url)}catch{r({success:false,error:"Invalid URL"});return}const f=["storage.googleapis.com","lh3.googleusercontent.com","lh4.googleusercontent.com","lh5.googleusercontent.com","lh6.googleusercontent.com","video.google.com","play-lh.googleusercontent.com","labs.google"];if(!(o.protocol==="https:"&&f.some(n=>o.hostname===n||o.hostname.endsWith("."+n)))){r({success:false,error:"Download URL not from allowed domain"});return}const g=e.url,u=g.split("?")[0],h=String(e.filename||""),s=/\.(png|jpe?g|webp|gif)$/i.test(h)||/\.(png|jpe?g|webp|gif)$/i.test(String(o.pathname||""));return(async()=>{ourPendingUrls.add(u),setTimeout(()=>ourPendingUrls.delete(u),3e4);let n=g;if(s)try{const l=await fetch(g,{credentials:"include"});if(!l.ok)throw new Error(`fetch_status_${l.status}`);const d=await l.blob(),c=await new Promise((_,w)=>{const p=new FileReader;p.onloadend=()=>_(String(p.result||"")),p.onerror=()=>w(new Error("image_data_url_failed")),p.readAsDataURL(d)});c&&c.startsWith("data:")&&(n=c)}catch{}registerPendingDirectName(h,n),chrome.downloads.download({url:n,filename:h,conflictAction:"uniquify"},l=>{l!==void 0&&(ourDownloadIds.add(l),setTimeout(()=>ourDownloadIds.delete(l),3e4)),ourPendingUrls.delete(u),chrome.runtime.lastError?r({success:false,error:chrome.runtime.lastError.message}):r(l===void 0?{success:false,error:"Download failed: downloadId is undefined."}:{success:true,downloadId:l})})})(),true}r({success:false,error:"Invalid message parameters (missing url or filename)"})}});chrome.runtime.onMessage.addListener(e=>{if(e?.type==="openLabsSiteDataSettings")chrome.tabs.create({url:"chrome://settings/content/siteDetails?site=https%3A%2F%2Flabs.google"})});

// ============================================================
// RED ONE — AUTO UPDATE SYSTEM
// ============================================================
(function() {
  const UPDATE_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 hours
  const UPDATE_URL_STORAGE_KEY = 'redone_update_url';
  const UPDATE_DISMISSED_KEY = 'redone_update_dismissed_version';
  const CURRENT_VERSION = chrome.runtime.getManifest().version;
  const DEFAULT_UPDATE_URL = '';

  function compareVersions(a, b) {
    const pa = a.split('.').map(Number);
    const pb = b.split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const na = pa[i] || 0;
      const nb = pb[i] || 0;
      if (na > nb) return 1;
      if (na < nb) return -1;
    }
    return 0;
  }

  async function getUpdateUrl() {
    return new Promise(resolve => {
      chrome.storage.local.get([UPDATE_URL_STORAGE_KEY], result => {
        resolve(result[UPDATE_URL_STORAGE_KEY] || DEFAULT_UPDATE_URL);
      });
    });
  }

  async function checkForUpdate() {
    const updateUrl = await getUpdateUrl();
    if (!updateUrl) {
      console.log('[RedOne Update] No update URL configured. Set via Settings.');
      return null;
    }
    try {
      console.log('[RedOne Update] Checking...', updateUrl);
      const response = await fetch(updateUrl, { cache: 'no-cache' });
      if (!response.ok) return null;
      const updateInfo = await response.json();
      const remoteVersion = updateInfo.version;
      if (!remoteVersion) return null;

      if (compareVersions(remoteVersion, CURRENT_VERSION) > 0) {
        console.log('[RedOne Update] New version:', remoteVersion);
        const dismissed = await new Promise(r => {
          chrome.storage.local.get([UPDATE_DISMISSED_KEY], res => r(res[UPDATE_DISMISSED_KEY]));
        });
        if (dismissed === remoteVersion) return null;

        await new Promise(r => {
          chrome.storage.local.set({ redone_available_update: updateInfo }, r);
        });
        try { chrome.runtime.sendMessage({ type: 'REDONE_UPDATE_AVAILABLE', updateInfo }).catch(() => {}); } catch(e) {}
        try {
          chrome.notifications.create('redone-update', {
            type: 'basic', iconUrl: 'images/icon128.png',
            title: 'Red One — Cập nhật mới!',
            message: 'Phiên bản ' + remoteVersion + ' đã sẵn sàng.\n' + (updateInfo.changelog || ''),
            priority: 1
          });
        } catch(e) {}
        return updateInfo;
      } else {
        chrome.storage.local.remove('redone_available_update');
        return null;
      }
    } catch (err) {
      console.log('[RedOne Update] Error:', err.message);
      return null;
    }
  }

  try {
    chrome.notifications.onClicked.addListener(id => {
      if (id === 'redone-update') {
        chrome.storage.local.get('redone_available_update', res => {
          if (res.redone_available_update?.download_url) {
            chrome.tabs.create({ url: res.redone_available_update.download_url });
          }
        });
      }
    });
  } catch(e) {}

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'REDONE_CHECK_UPDATE') {
      checkForUpdate().then(info => sendResponse({ hasUpdate: !!info, updateInfo: info }));
      return true;
    }
    if (msg.type === 'REDONE_DISMISS_UPDATE') {
      chrome.storage.local.set({ [UPDATE_DISMISSED_KEY]: msg.version, redone_available_update: null });
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'REDONE_SET_UPDATE_URL') {
      chrome.storage.local.set({ [UPDATE_URL_STORAGE_KEY]: msg.url || '' });
      sendResponse({ ok: true, url: msg.url });
      return;
    }
    if (msg.type === 'REDONE_GET_UPDATE_URL') {
      getUpdateUrl().then(url => sendResponse({ url }));
      return true;
    }
    if (msg.type === 'REDONE_DOWNLOAD_UPDATE') {
      if (msg.download_url) {
        chrome.downloads.download({ url: msg.download_url, conflictAction: 'uniquify' }, downloadId => {
          sendResponse({ ok: !chrome.runtime.lastError, downloadId, error: chrome.runtime.lastError?.message });
        });
      } else { sendResponse({ ok: false, error: 'No download URL' }); }
      return true;
    }
  });

  setInterval(checkForUpdate, UPDATE_CHECK_INTERVAL_MS);
  setTimeout(checkForUpdate, 30000);
  console.log('[RedOne Update] Initialized. v' + CURRENT_VERSION);
})();
